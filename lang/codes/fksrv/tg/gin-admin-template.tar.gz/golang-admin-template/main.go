package main

import (
	"golang-admin-template/routes"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	// 设置模板文件目录
	r.LoadHTMLGlob("templates/*")
	// 设置静态文件目录
	r.Static("/static", "./static")
	// 初始化路由
	routes.SetupRoutes(r)
	// 运行服务器
	r.Run(":8080")
}
