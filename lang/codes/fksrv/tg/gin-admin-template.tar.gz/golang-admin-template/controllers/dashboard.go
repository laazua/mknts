package controllers

import (
	"fmt"

	"github.com/gin-gonic/gin"
)

func Dashboard(c *gin.Context) {
	fmt.Println("xxxxxx")
	c.HTML(200, "dashboard.html", nil)
}
