package controllers

import "github.com/gin-gonic/gin"

func Settings(c *gin.Context) {
	c.HTML(200, "settings.html", nil)
}
