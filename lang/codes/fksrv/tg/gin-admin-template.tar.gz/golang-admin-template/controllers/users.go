package controllers

import "github.com/gin-gonic/gin"

func Users(c *gin.Context) {
	c.HTML(200, "users.html", nil)
}
