package routes



import (
    "github.com/gin-gonic/gin"
    "golang-admin-template/controllers"
)

func SetupRoutes(r *gin.Engine) {
    r.GET("/", controllers.Index)
    r.GET("/dashboard", controllers.Dashboard)
    r.GET("/users", controllers.Users)
    r.GET("/settings", controllers.Settings)
}
