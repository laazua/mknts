from flask import Flask, render_template, jsonify

from app.api.auth import auth_bp
from app.api.user import user_bp


def create_app():
    # 创建Flask应用
    app = Flask(__name__)

    # 导入蓝图

    # 注册蓝图
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(user_bp, url_prefix="/api/user")

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/admin")
    def admin():
        return render_template("admin.html")

    @app.route("/api/data")
    def get_data():
        data = {"message": "Hello, this is your data!"}
        return jsonify(data)

    return app
