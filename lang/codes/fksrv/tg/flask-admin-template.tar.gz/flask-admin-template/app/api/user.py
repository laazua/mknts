from flask import Blueprint, jsonify

user_bp = Blueprint("user", __name__)


@user_bp.route("/profile")
def profile():
    # 模拟获取用户信息
    user_info = {"username": "admin", "email": "admin@example.com"}
    return jsonify(user_info)
