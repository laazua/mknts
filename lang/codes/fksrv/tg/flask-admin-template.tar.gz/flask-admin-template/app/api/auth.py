from flask import Blueprint, jsonify

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    # 模拟登录逻辑
    return jsonify({"message": "Logged in successfully!"})
