#!/usr/bin/bash


function start_app() {
    isrun=$(check_app)
    if [ "${isrun}" == "2" ];then
	echo "openvpn is running"
	exit
    fi
    local log_path="/var/log/openvpn"
    [ ! -d "${log_path}" ] && mkdir "${log_path}"
    /usr/sbin/openvpn --config /etc/openvpn/client/client.ovpn >>"${log_path}/openv.log" 2>&1 &
    if [ $?  -eq 0 ];then
        echo "start openvpn success"
    else
	echo "start openvpn failure"
    fi
}

function stop_app() {
    isrun=$(check_app)
    if [ "${isrun}" == "1" ];then
	echo "openvpn is stopped"
	exit
    fi
    kill "$(pgrep openvpn)" && echo "stop openvpn..."
}

function check_app() {
    local pid=$(pgrep openvpn)
    if [ "${pid}" == "" ];then
	echo 1
    else
	echo 2
    fi
}

if [ "$1" == "start" ];then
    start_app
    exit
fi

if [ "$1" == "check" ];then
    isrun=$(check_app)
    if [ "${isrun}" == "1" ];then
	echo "openvpn is stopped"
    else
	echo "openvpn is running"
    fi
    exit
fi

if [ "$1" == "stop" ];then
    stop_app
    exit
fi

echo "bash $0 [start|stop|check]"
